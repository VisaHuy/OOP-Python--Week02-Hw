
    a -= 1
print(factorial)