x = input()
a = int(x)
factorial = 1
while(a > 0):
    factorial *= a
    a -= 1
print(factorial) 